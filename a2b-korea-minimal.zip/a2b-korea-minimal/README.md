# A2B Korea — Minimal Next.js Project

- Next.js 14 (App Router)
- Locales: ko (default), en, ru
- Pages: /ko, /en, /ru

## Run locally
npm install
npm run dev
open http://localhost:3000/ko
